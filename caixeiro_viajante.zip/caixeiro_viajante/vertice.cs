﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caixeiro_viajante
{
    class vertice
    {
        public int id;
        public bool visitado;
        public int grau = 0;
        public aresta adjacentes = null;
        public vertice proximo;
    }
}
