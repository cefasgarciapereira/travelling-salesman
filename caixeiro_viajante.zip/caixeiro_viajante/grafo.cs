﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caixeiro_viajante
{
    class grafo
    {
        public vertice inicio = null;
        public int numVertices = 0;

        private int[] p;
        private int[] caminho;
        private int custo;

        public vertice buscaVertice(int id)
        {
            vertice aux = inicio;

            while ((aux != null) && (aux.id != id))
                aux = aux.proximo;

            return (aux);
        }

        public aresta buscaAresta(int vi, int vf)
        {
            vertice auxV = inicio;
            aresta auxA;

            while ((auxV != null) && (auxV.id != vi))
                auxV = auxV.proximo;

            if (auxV == null)
                return (null);
            else
            {
                auxA = auxV.adjacentes;

                while ((auxA != null) && (auxA.destino != vf))
                    auxA = auxA.proxima;

                return (auxA);
            }
        }

        private void permuta(int[] vertices, int t, int v)
        {
            p = new int[t];
            caminho = new int[t + 2];
            permuta(vertices, t, 0, v);
        }

        private void permuta(int[] vertices, int t, int n, int v)
        {
            bool achou;
            int i, j;

            if (n == t)
                calculaCaminho(v);
            else
            {
                for (i = 0; i < t; i++)
                {
                    achou = false;

                    for (j = 0; j < n; j++)
                        if (p[j] == vertices[i])
                            achou = true;
                    if (!achou)
                    {
                        p[n] = vertices[i];
                        permuta(vertices, t, n + 1, v);
                    }
                }
            }
        }

        private void calculaCaminho(int v)
        {
            int c, i;
            aresta aux;

            aux = buscaAresta(v,p[0]);
            c = aux.custo;

            for (i = 0; i < p.Length - 1 ; i++)
            {
                aux = buscaAresta(p[i],p[i+1]);
                c = c + aux.custo;
            }

            aux = buscaAresta(p[p.Length - 1], v);
            c = c + aux.custo;

            if (c < custo)
            {
                custo = c;

                caminho[0] = v;
                for (i = 0; i < p.Length; i++)
                    caminho[i + 1] = p[i];

                caminho[p.Length + 1] = v;
            }
        }

        public void pcv_solucaoOtima(int v)
        {
            int i = 0;
            int[] vertices = new int[numVertices];
            vertice aux = inicio;

            while (aux != null)
            {
                if (aux.id != v)
                {
                    vertices[i] = aux.id;
                    i++;
                }
                aux = aux.proximo;
            }

            custo = 10000;
            permuta(vertices, numVertices - 1, v);

            Console.Write("Custo: {0}\nCaminho: ", custo);

            for (i = 0; i < caminho.Length; i++)
                Console.Write("{0}, ", caminho[i]);
        }

        public void pcv_heuristica(int v)
        {
            int menorCusto, i, j = 1, u;
            vertice auxV = inicio, w, p;
            aresta auxA, a;

            while (auxV != null)
            {
                auxV.visitado = false;
                auxV = auxV.proximo;
            }

            caminho = new int[numVertices + 1];

            p = buscaVertice(v);
            p.visitado = true;
            caminho[0] = p.id;
            custo = 0;

            for (i = 1; i < numVertices; i++)
            {
                auxA = p.adjacentes;
                menorCusto = 10000;
                u = 0;

                while (auxA != null)
                {
                    w = buscaVertice(auxA.destino);
                    if ((w.id != v) && (!w.visitado) && (auxA.custo < menorCusto))
                    {
                        menorCusto = auxA.custo;
                        u = auxA.destino;
                    }

                    auxA = auxA.proxima;
                }

                custo = custo + menorCusto;

                p = buscaVertice(u);
                p.visitado = true;
                caminho[j] = p.id;
                j++;
            }

            a = buscaAresta(p.id, v);
            custo = custo + a.custo;

            caminho[j] = v;

            Console.Write("Custo: {0}\nCaminho: ", custo);

            for (i = 0; i < caminho.Length; i++)
                Console.Write("{0}, ", caminho[i]);
        }

        public void exibirGrafo()
        {
            vertice auxV = inicio;
            aresta auxA;

            Console.WriteLine("O grafo tem {0} vértices.", numVertices);

            while (auxV != null)
            {
                Console.Write("Id: {0} Grau: {1} ", auxV.id, auxV.grau);
                Console.Write("Vértices: ");

                auxA = auxV.adjacentes;
                while (auxA != null)
                {
                    Console.Write("{0} ({1}), ", auxA.destino, auxA.custo);
                    auxA = auxA.proxima;
                }

                Console.WriteLine();
                auxV = auxV.proximo;
            }
        }

        public void incluirVertice(int id)
        {
            vertice novo = new vertice();

            novo.id = id;
            novo.proximo = inicio;
            inicio = novo;

            numVertices++;
        }

        public void incluirAresta(int vi, int vf, int c)
        {
            vertice auxV = inicio;
            aresta nova = new aresta();

            while (auxV.id != vi)
            {
                auxV = auxV.proximo;
            }

            auxV.grau++;
            nova.proxima = auxV.adjacentes;
            auxV.adjacentes = nova;
            nova.destino = vf;
            nova.custo = c;

            nova = new aresta();
            auxV = inicio;

            while (auxV.id != vf)
            {
                auxV = auxV.proximo;
            }

            auxV.grau++;
            nova.proxima = auxV.adjacentes;
            auxV.adjacentes = nova;
            nova.destino = vi;
            nova.custo = c;
        }

        public void removerVertice(int id)
        {
            vertice auxV = inicio, ant = null;

            while (auxV != null)
            {
                if (verificaAresta(id, auxV.id))
                    removerAresta(id, auxV.id);

                auxV = auxV.proximo;
            }

            auxV = inicio;

            while (auxV.id != id)
            {
                ant = auxV;
                auxV = auxV.proximo;
            }

            numVertices--;

            if (ant == null)
                inicio = inicio.proximo;
            else
                ant.proximo = auxV.proximo;
        }

        public void removerAresta(int vi, int vf)
        {
            vertice auxV = inicio;
            aresta auxA, ant;

            while (auxV.id != vi)
                auxV = auxV.proximo;

            auxV.grau--;

            auxA = auxV.adjacentes;
            ant = null;

            while (auxA.destino != vf)
            {
                ant = auxA;
                auxA = auxA.proxima;
            }

            if (ant == null)
                auxV.adjacentes = auxA.proxima;
            else
                ant.proxima = auxA.proxima;

            auxV = inicio;

            while (auxV.id != vf)
                auxV = auxV.proximo;

            auxV.grau--;

            auxA = auxV.adjacentes;
            ant = null;

            while (auxA.destino != vi)
            {
                ant = auxA;
                auxA = auxA.proxima;
            }

            if (ant == null)
                auxV.adjacentes = auxA.proxima;
            else
                ant.proxima = auxA.proxima;
        }

        public void alterarCustoAresta(int vi, int vf, int c)
        {
            aresta aux = buscaAresta(vi, vf);
            aux.custo = c;

            aux = buscaAresta(vf, vi);
            aux.custo = c;
        }

        public bool verificaVertice(int id)
        {
            vertice auxV = inicio;

            while ((auxV != null) && (auxV.id != id))
                auxV = auxV.proximo;

            return (auxV != null);
        }

        public bool verificaAresta(int vi, int vf)
        {
            vertice auxV = inicio;
            aresta auxA;

            while (auxV.id != vi)
                auxV = auxV.proximo;

            auxA = auxV.adjacentes;

            while ((auxA != null) && (auxA.destino != vf))
                auxA = auxA.proxima;

            return (auxA != null);
        }

        public bool vazio()
        {
            return (inicio == null);
        }

        public bool completo()
        {
            vertice auxV = inicio;
            bool completo;

            if (inicio == null)
                return (false);
            else
            {
                completo = true;

                while ((auxV != null) && (completo))
                {
                    if (auxV.grau != (numVertices - 1))
                        completo = false;
                    else
                        auxV = auxV.proximo;
                }

                return (completo);
            }
        }

        public bool totalmenteDesconexo()
        {
            vertice auxV = inicio;
            bool totalmenteDesconexo = true;

            while ((auxV != null) && (totalmenteDesconexo))
            {
                if (auxV.grau != 0)
                    totalmenteDesconexo = false;
                else
                    auxV = auxV.proximo;
            }

            return (totalmenteDesconexo);
        }

        public grafo complemento()
        {
            vertice auxV1 = inicio, auxV2;
            grafo gc = new grafo();

            while (auxV1 != null)
            {
                gc.incluirVertice(auxV1.id);
                auxV1 = auxV1.proximo;
            }

            auxV1 = inicio;

            while (auxV1 != null)
            {
                auxV2 = inicio;

                while (auxV2 != null)
                {
                    if ((auxV1.id > auxV2.id) && (!verificaAresta(auxV1.id, auxV2.id)))
                        gc.incluirAresta(auxV1.id, auxV2.id, buscaAresta(auxV1.id, auxV2.id).custo);

                    auxV2 = auxV2.proximo;
                }

                auxV1 = auxV1.proximo;
            }

            return (gc);
        }

        public void reiniciarGrafo()
        {
            inicio = null;
            numVertices = 0;
        }

        public void lerGrafo()
        {
            System.IO.StreamReader arq;
            string s, vi, vf, c, nomeArq;
            int i, j, n;

            reiniciarGrafo();

            Console.Write("Digite nome do arquivo texto (sem extensão): ");
            nomeArq = Console.ReadLine();

            arq = new System.IO.StreamReader(nomeArq + ".txt");

            n = int.Parse(arq.ReadLine());

            for (i = 1; i <= n; i++)
                incluirVertice(int.Parse(arq.ReadLine()));

            n = int.Parse(arq.ReadLine());

            for (i = 1; i <= n; i++)
            {
                s = arq.ReadLine();
                vi = "";
                vf = "";
                c = "";

                j = 0;
                while (s[j] != ' ')
                {
                    vi = vi + s[j];
                    j++;
                }

                j++;
                while (s[j] != ' ')
                {
                    vf = vf + s[j];
                    j++;
                }

                j++;
                while (j < s.Length)
                {
                    c = c + s[j];
                    j++;
                }

                if (verificaVertice(int.Parse(vi)) && verificaVertice(int.Parse(vf)) &&
                    (int.Parse(vi) != int.Parse(vf)) && !(verificaAresta(int.Parse(vi), int.Parse(vf))))
                    incluirAresta(int.Parse(vi), int.Parse(vf), int.Parse(c));
            }

            arq.Close();
        }
    }
}
