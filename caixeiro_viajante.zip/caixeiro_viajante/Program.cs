﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caixeiro_viajante
{
    class Program
    {
        static int menu()
        {
            Console.Clear();
            Console.WriteLine("1 - Exibir grafo");
            Console.WriteLine("2 - Incluir vértice");
            Console.WriteLine("3 - Incluir aresta");
            Console.WriteLine("4 - Remover vértice");
            Console.WriteLine("5 - Remover aresta");
            Console.WriteLine("6 - Alterar custo de aresta");
            Console.WriteLine("7 - Verificar existência de vértice");
            Console.WriteLine("8 - Verificar existência de aresta");
            Console.WriteLine("9 - Verificar completo");
            Console.WriteLine("10 - Solução Ótima Caixeiro Viajante");
            Console.WriteLine("11 - Heurística Caixeiro Viajante");
            Console.WriteLine("12 - Reiniciar grafo");
            Console.WriteLine("13 - Ler grafo");
            Console.WriteLine("15 - Sair");
            Console.Write("Opção: ");

            return (int.Parse(Console.ReadLine()));
        }

        static void Main(string[] args)
        {
            int op, id, vi, vf, c;
            grafo G = new grafo();

            do
            {
                op = menu();

                switch (op)
                {
                    case 1:  // exibir grafo
                        Console.Clear();
                        G.exibirGrafo();

                        Console.ReadKey();
                        break;

                    case 2:  // incluir vertice
                        Console.Clear();
                        Console.Write("Digite o id do vértice: ");
                        id = int.Parse(Console.ReadLine());

                        if (G.verificaVertice(id))
                            Console.WriteLine("O vértice {0} já existe no grafo.", id);
                        else
                            G.incluirVertice(id);

                        Console.ReadKey();
                        break;

                    case 3:  // incluir aresta
                        Console.Clear();
                        Console.Write("Digite o id do vértice inicial: ");
                        vi = int.Parse(Console.ReadLine());
                        Console.Write("Digite o id do vértice final: ");
                        vf = int.Parse(Console.ReadLine());
                        Console.Write("Digite o custo da aresta: ");
                        c = int.Parse(Console.ReadLine());

                        if (vi == vf)
                            Console.WriteLine("Os vértices devem ser diferentes.");
                        else
                        {
                            if (!G.verificaVertice(vi) || !G.verificaVertice(vf))
                                Console.WriteLine("O vértice {0} e/ou o vértice {1} não existem no grafo.", vi, vf);
                            else
                            {
                                if (G.verificaAresta(vi, vf))
                                    Console.WriteLine("A aresta entre o vértice {0} e o vértice {1} já existe no grafo.", vi, vf);
                                else
                                    G.incluirAresta(vi, vf, c);
                            }
                        }
                        Console.ReadKey();
                        break;

                    case 4:  // remover vértice
                        Console.Clear();
                        Console.Write("Digite o id do vértice: ");
                        id = int.Parse(Console.ReadLine());

                        if (!G.verificaVertice(id))
                            Console.WriteLine("O vértice {0} não existe no grafo.", id);
                        else
                            G.removerVertice(id);

                        Console.ReadKey();
                        break;

                    case 5:  // remover aresta
                        Console.Clear();
                        Console.Write("Digite o id do vértice inicial: ");
                        vi = int.Parse(Console.ReadLine());
                        Console.Write("Digite o id do vértice final: ");
                        vf = int.Parse(Console.ReadLine());

                        if (!G.verificaVertice(vi) || !G.verificaVertice(vf))
                            Console.WriteLine("O vértice {0} e/ou o vértice {1} não existem no grafo.", vi, vf);
                        else
                        {
                            if (!G.verificaAresta(vi, vf))
                                Console.WriteLine("A aresta entre o vértice {0} e o vértice {1} não existe no grafo.", vi, vf);
                            else
                                G.removerAresta(vi, vf);
                        }
                        Console.ReadKey();
                        break;

                    case 6:  // alterar custo de aresta
                        Console.Clear();
                        Console.Write("Digite o id do vértice inicial: ");
                        vi = int.Parse(Console.ReadLine());
                        Console.Write("Digite o id do vértice final: ");
                        vf = int.Parse(Console.ReadLine());

                        if (!G.verificaVertice(vi) || !G.verificaVertice(vf))
                            Console.WriteLine("O vértice {0} e/ou o vértice {1} não existem no grafo.", vi, vf);
                        else
                        {
                            if (!G.verificaAresta(vi, vf))
                                Console.WriteLine("A aresta entre o vértice {0} e o vértice {1} não existe no grafo.", vi, vf);
                            else
                            {
                                Console.Write("Digite o novo custo da aresta: ");
                                c = int.Parse(Console.ReadLine());
                                G.alterarCustoAresta(vi, vf, c);
                            }
                        }
                        Console.ReadKey();
                        break;

                    case 7:  // verificar vértice
                        Console.Clear();
                        Console.Write("Digite o id do vértice: ");
                        id = int.Parse(Console.ReadLine());

                        if (G.verificaVertice(id))
                            Console.WriteLine("O vértice {0} já existe no grafo.", id);
                        else
                            Console.WriteLine("O vértice {0} não existe no grafo.", id);
                        Console.ReadKey();
                        break;

                    case 8:  // verificar aresta
                        Console.Clear();
                        Console.Write("Digite o id do vértice inicial: ");
                        vi = int.Parse(Console.ReadLine());
                        Console.Write("Digite o id do vértice final: ");
                        vf = int.Parse(Console.ReadLine());

                        if (!G.verificaVertice(vi) || !G.verificaVertice(vf))
                            Console.WriteLine("O vértice {0} e/ou o vértice {1} não existem no grafo.", vi, vf);
                        else
                        {
                            if (G.verificaAresta(vi, vf))
                                Console.WriteLine("A aresta entre o vértice {0} e o vértice {1} já existe no grafo.", vi, vf);
                            else
                                Console.WriteLine("A aresta entre o vértice {0} e o vértice {1} não existe no grafo.", vi, vf);
                        }
                        Console.ReadKey();
                        break;

                    case 9:  // verificar completo
                        Console.Clear();
                        if (G.vazio())
                            Console.WriteLine("O grafo está vazio.");
                        else
                        {
                            if (G.completo())
                                Console.WriteLine("O grafo é completo.");
                            else
                                Console.WriteLine("O grafo não é completo.");
                        }
                        Console.ReadKey();
                        break;

                    case 10:  // solucao otima caixeiro viajante
                        Console.Clear();

                        if (G.numVertices < 3)
                            Console.WriteLine("O grafo deve ter pelo menos 3 vértices.");
                        else
                        {
                            if (!G.completo())
                                Console.WriteLine("O grafo não é completo");
                            else
                            {
                                Console.Write("Digite o id do vértice inicial: ");
                                vi = int.Parse(Console.ReadLine());

                                if (!G.verificaVertice(vi))
                                    Console.WriteLine("O vértice {0} não existe no grafo.", vi);
                                else
                                {
                                    // aqui deve ser feita a medida do tempo de execucao
                                    // da obtencao da solucao otima do PCV
                                    G.pcv_solucaoOtima(vi);
                                }                                    
                            }
                        }

                        Console.ReadKey();
                        break;

                    case 11:  // heurística caixeiro viajante
                        Console.Clear();

                        if (G.numVertices < 3)
                            Console.WriteLine("O grafo deve ter pelo menos 3 vértices.");
                        else
                        {
                            if (!G.completo())
                                Console.WriteLine("O grafo não é completo");
                            else
                            {
                                Console.Write("Digite o id do vértice inicial: ");
                                vi = int.Parse(Console.ReadLine());

                                if (!G.verificaVertice(vi))
                                    Console.WriteLine("O vértice {0} não existe no grafo.", vi);
                                else
                                {
                                    // aqui deve ser feita a medida do tempo de execucao
                                    // da obtencao da solucao heuristica do PCV
                                    G.pcv_heuristica(vi);
                                }                                    
                            }
                        }

                        Console.ReadKey();
                        break;

                    case 12: // reiniciar grafo
                        Console.Clear();
                        G.reiniciarGrafo();
                        Console.ReadKey();
                        break;

                    case 13: // ler grafo
                        Console.Clear();
                        G.lerGrafo();
                        Console.ReadKey();
                        break;
                }
            } while (op != 15);
        }
    }
}
